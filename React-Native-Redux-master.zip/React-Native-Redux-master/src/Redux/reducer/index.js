// jangan rubah
import {combineReducers} from 'redux'

import {HomeReducer} from './HomeReeucer'

export default combineReducers({
    HomeReducer
})
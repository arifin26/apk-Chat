//bisa di tambah sesuai kebutuhan
export const CHANGE_NAME = "CHANGE_NAME"
export const CHANGE_UMUR = 'CHANGE_UMUR'
export const CHANGE_ALAMAT = "CHANGE_ALAMAT"
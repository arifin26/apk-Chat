// eslint-disable-next-line no-native-reassign
window.global = window
